package com.sunbeaminfo.ecomm.utils;

public class Utils {
    public static String getUrl(String path) {
        return Constants.BASE_URL + path;
    }
}
